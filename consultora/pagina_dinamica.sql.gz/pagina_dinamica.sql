-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 26-10-2012 a las 14:54:35
-- Versión del servidor: 5.1.36
-- Versión de PHP: 5.2.9-2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `pagina_dinamica`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contenido`
--

CREATE TABLE IF NOT EXISTS `contenido` (
  `idcontenido` int(11) NOT NULL AUTO_INCREMENT,
  `idmenu` int(11) DEFAULT NULL,
  `contenido` text,
  `Imagen` varchar(50) DEFAULT NULL,
  `Indicado` tinyint(4) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idcontenido`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `contenido`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `idmenu` int(11) NOT NULL AUTO_INCREMENT,
  `idpagina` int(11) DEFAULT NULL,
  `texto` varchar(50) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idmenu`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `menu`
--

INSERT INTO `menu` (`idmenu`, `idpagina`, `texto`, `estado`) VALUES
(1, 1, 'Home', 1),
(2, 1, 'Comentario', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticia`
--

CREATE TABLE IF NOT EXISTS `noticia` (
  `idcontenido` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(50) DEFAULT NULL,
  `contenido` text,
  `prioridad` tinyint(4) DEFAULT NULL,
  `titulo` varchar(50) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idcontenido`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `noticia`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagina`
--

CREATE TABLE IF NOT EXISTS `pagina` (
  `idpagina` int(11) NOT NULL AUTO_INCREMENT,
  `dominio` varchar(100) NOT NULL,
  `titulo` varchar(50) DEFAULT NULL,
  `subtitulo` varchar(100) DEFAULT NULL,
  `imagen1` varchar(50) DEFAULT NULL,
  `imagen2` varchar(50) DEFAULT NULL,
  `imagen3` varchar(50) DEFAULT NULL,
  `pie` text,
  `plantilla` varchar(50) DEFAULT NULL,
  `ancho` double(16,2) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idpagina`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `pagina`
--

INSERT INTO `pagina` (`idpagina`, `dominio`, `titulo`, `subtitulo`, `imagen1`, `imagen2`, `imagen3`, `pie`, `plantilla`, `ancho`, `estado`) VALUES
(1, 'www.google.com.bo', 'Iglesia', 'nueva esperanza', 'slide1.jpg', 'slide2.jpg', 'slide3.jpg', '<p style="text-align: center;"><span style="color: #888888;"> Pie de pagina</span></p>', '1', 100.50, 1),
(2, 'www.google.com.bo', 'Gran Promosion', 'nuevo', 'pagina2img1.jpg', 'pagina2img2.jpg', 'pagina2img3.jpg', '<p>Pie de pagina</p>', '2', 100.50, 1),
(3, 'www.google.com.bo', 'Negra', 'Soy muy negra', 'pagina3img1.jpg', 'pagina3img2.jpg', 'pagina3img3.jpg', '<p style="text-align: center;"><span style="color: #3366ff; font-size: large;">Soy la super negra</span></p>', '1', 100.50, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `idusuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `nick` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `permiso` tinyint(4) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idusuario`, `nombre`, `nick`, `password`, `fecha`, `permiso`, `estado`) VALUES
(1, 'Ronald Miguel Apaza Guerreros', 'root', 'root', '2012-10-23', 1, 1),
(3, 'Ronald Miguel apaza Guerreros', 'ronald2', '123456', '2012-10-23', 2, 1),
(4, 'Ronald Miguel apaza Guerreros', 'ronald', '1234', '2012-10-23', 2, 1),
(5, 'Ronald Miguel', 'uno', 'uno', '2012-10-23', 1, 1);
