<div class="menu-item item-now-showing">
    <a href="cartelera.php"><div class="item-now-showing"></div></a>    
</div>
<div class="menu-item item-directions">
    <a href="donde_estamos.php"><div class="item-directions"></div></a>   
</div>
<div class="menu-item item-about-us">
    <a href="quienes_somos.php"><div class="item-about-us"></div></a>    
</div>
<div class="menu-item item-contact-us">
    <a href="contacto.php"><div class="item-contact-us"></div></a>    
</div>
<div class="menu-item item-snack-bar">
    <a href="monchies.php"><div class="item-snack-bar"></div></a>    
</div>
<div class="menu-item item-social">
    <a href="coyoteando.php"><div class="item-social"></div></a>    
</div>
<div class="menu-item item-faq">
    <a href="dudas.php"><div class="item-faq"></div></a>    
</div>