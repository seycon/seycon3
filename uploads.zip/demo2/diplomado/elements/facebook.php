<div class="social-item">
    <div class="red">
        <a href="https://www.facebook.com/AutocinemaCoyote" target="_blank">Autocinema Coyote</a> en Facebook</div>        
    <br/>
    <div class="social-facebook">        
        <iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FAutocinemaCoyote&amp;
                width=550&amp;height=330&amp;colorscheme=light&amp;show_faces=true&amp;border_color=%23FFFFFF&amp;
                stream=false&amp;header=false&amp;appId=162933353832616" scrolling="no"
                frameborder="0" style="border:none; overflow:hidden; width:550px; height:330px;" 
                allowTransparency="true"></iframe>
    </div>
    <div class="cleared"></div>
</div>
