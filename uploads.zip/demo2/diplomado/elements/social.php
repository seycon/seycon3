<a target="_blank" href="https://twitter.com/#!/AutocinemaC"><img src="image/twitter_logo.png" alt="Twitter" title="Twitter"/></a>
<a target="_blank" href="http://www.facebook.com/home.php?#!/pages/Autocinema-Coyote/152741371450402"><img src="image/facebook_logo.png" alt="Facebook" title="Facebook"/></a>
<a target="_blank" href="http://www.youtube.com/user/AutocinemaCoyote#g/a"><img src="image/youtube_logo.png" alt="Youtube" title="Youtube"/></a>
<a target="_blank" href="http://www.vimeo.com/20734248"><img src="image/vimeo_logo.png" alt="Vimeo" title="Vimeo"/></a>