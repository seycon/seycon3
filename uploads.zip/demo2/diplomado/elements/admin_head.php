<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
<title><?php echo $title?></title>
<link href="../css/autocinema.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../js/jquery-1.4.3.min.js"></script>   