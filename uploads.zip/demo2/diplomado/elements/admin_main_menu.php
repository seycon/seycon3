<div class="admin-menu">
    <div class="admin-menu-title">Admin Menu</div>
    <div class="admin-menu-item">
        &rarr; <a href="index.php">Películas</a>
    </div>
    <div class="admin-menu-item">
        &rarr; <a href="mensajes.php">Mensajes</a>
    </div>
    <div class="admin-menu-item">
        &rarr; <a href="recomendaciones.php">Recomendaciones</a>
    </div>    
    <div class="admin-menu-item">
        &rarr; <a href="contenidos.php">Contenidos</a>
    </div>   
    <div class="admin-menu-item">
        &rarr; <a href="fondos.php">Fondos</a>
    </div>   
    <div class="admin-menu-item">
        &rarr; <a href="salir.php">Salir</a>
    </div>
</div>