<?php
phpinfo();
echo 'hola';
?>
