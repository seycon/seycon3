<?php
session_start();
include('conexion.php');
$db = new MYSQL();
if (!isset($_SESSION['softLogeoadmin'])){
       header("Location: index.php");	
}
$estructura = $_SESSION['estructura'];
if (!$db->tieneAccesoFile($estructura['Recursos'],'Planilla de Bonos','bonos.php')){
  header("Location: cerrar.php");	
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/templaterecursos.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<script type="text/javascript" src="js/submenus.js"></script>

<script type="text/javascript"> 
$(document).ready(function(){
 
	$("ul.submenu").parent().append("<span></span>"); 	
	$("ul.menu li span").click(function() { //Al hacer click se ejecuta...
		
		//Con este codigo aplicamos el movimiento de arriva y abajo para el submenu
		$(this).parent().find("ul.submenu").slideDown('fast').show(); //Menu desplegable al hacer click 
		$(this).parent().hover(function() {
		}, function(){	
			$(this).parent().find("ul.submenu").slideUp('slow'); //Ocultamos el submenu cuando el raton sale fuera del submenu
		});
 
		}).hover(function() { 
			$(this).addClass("subhover"); //Agregamos la clase subhover
		}, function(){	//Cunado sale el cursor, sacamos la clase
			$(this).removeClass("subhover"); 
	});
	
	$("ul.menuH li span").click(function() { //Al hacer click se ejecuta...
		
		//Con este codigo aplicamos el movimiento de arriva y abajo para el submenu
		$(this).parent().find("ul.submenu").slideDown('fast').show(); //Menu desplegable al hacer click
 
		$(this).parent().hover(function() {
		}, function(){	
			$(this).parent().find("ul.submenu").slideUp('slow'); //Ocultamos el submenu cuando el raton sale fuera del submenu
		});
 
		}).hover(function() { 
			$(this).addClass("subhover"); //Agregamos la clase subhover
		}, function(){	//Cunado sale el cursor, sacamos la clase
			$(this).removeClass("subhover"); 
	});
 
});
</script>
<!-- InstanceBeginEditable name="doctitle" -->
<title>Sistema Empresarial y Contable – Seycon 2011</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->



<!-- TinyMCE -- aumentar un simbolo de mayor para activar el editor de texto avanzado TinyMCE
<script language='javascript' type='text/javascript' src='jscripts/tiny_mce/tiny_mce.js'></script>
<script language='javascript' type='text/javascript' src='conftiny.js'></script>
<!-- /TinyMCE -->
<link rel="stylesheet" href="css/estilos.css" type="text/css"/>
<link rel="stylesheet" href="bonos/bonos.css" type="text/css" />
<script src="autocompletar/FuncionesUtiles.js"></script>
<script src="bonos/bonos.js"></script>


<!-- InstanceEndEditable -->
 <link href="SpryAssets/SpryAccordion.css" rel="stylesheet" type="text/css" /> 
</head> 

<body >

<div class="franjaCabecera">
<div class="franjaInicial"></div>
<div class="alineadorFrontalSeycon">

<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td > 
    <div class="headerPrincipal">
       <div class="logoEmpresa"></div>
        
          <div class="tituloEmpresa"><?php echo "Sistema Empresarial y Contable";?></div>
          <div class="nitEmpresa"> 
		  <?php 
              $cadenaNit = $_SESSION['nit'];
			  if (strlen($cadenaNit) > 15)	{			  
				  $cadenaNit = substr($cadenaNit,0,15);
			  }
              $cadena = $_SESSION['nombreEmpresa'];
			  if (strlen($cadena) > 35) {				  
				  $cadena = substr($cadena,0,35);
			  }  
              echo $cadena." - ".$cadenaNit;
          ?>
          </div>
      </div>
    </td>
  </tr>
  <tr>
    <td >
     <div class="menu2"></div>
    </td>
  </tr>
</table>
  <div class="contenedorMenuFrontal">
   <ul class="menu"> 
            <li> 
                <a href="#">Inventario</a>
                <?php 
					  $estructura = $_SESSION['estructura'];
					  $menus = $estructura['Inventario'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Inventario&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?>
            </li> 
            <li> 
                <a href="#">Recursos</a> 
                <?php 
					  $menus = $estructura['Recursos'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Recursos&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?>
            </li>
            <li> 
                <a href="#">Activos</a> 
                <?php 
					  $menus = $estructura['Activo'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Activo&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?>
            </li> 
             <li> 
                <a href="#">Ventas</a> 
                <?php 
					  $menus = $estructura['Ventas'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Ventas&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?> 
            </li> 
             <li> 
                <a href="#">Contabilidad</a> 
                <?php 
					  $menus = $estructura['Contabilidad'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Contabilidad&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?> 
            </li> 
             <li> 
                <a href="#">Agenda</a> 
                <?php 
					  $menus = $estructura['Agenda'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Agenda&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?>  
            </li>  
        </ul> 
  
  
       
           <div class="usuarioSistema">
            <div class="borde1Usuario"></div>
            <div class="borde2Usuario">
               <div class="sessionHerramienta">
               <ul class="menuH"> 
                 <li> 
                 <?php 
					  $estructura = $_SESSION['estructura'];
					  $menus = $estructura['Administracion'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Administracion&opt=$titulo'>".$titulo."</a></li>";
						 }
						  echo "<li><a href='cerrar.php'>Salir</a></li>";
						 echo "</ul>";
					   }
				 ?>
            </li>
               
               </ul>
               </div>
               <div class="nombreUsuario">
            <?php
            $cadena = $_SESSION['nombre_usuario'];
              if (strlen($cadena) > 15) {				  
                $cadena = substr($cadena,0,15);
			  }
            echo ucfirst($cadena);				
            ?> </div>
            </div>
          </div> 
         
    </div>       
   </div>  
</div>

<div class="container">

  <!-- InstanceBeginEditable name="Regioneditable" -->

<div class="cabeceraFormulario">

<div class="menuTituloFormulario"> Recursos > Planilla de Bonos </div>
<div class="menuFormulario"> 
 <?php
   $estructura = $_SESSION['estructura'];
   $menus = $estructura['Recursos'];
   $privilegios = $db->getOpciones($menus, "Planilla de Bonos"); 
   $option = "";
   for ($i = 0; $i < count($privilegios); $i++) {	
	   $link = "location.href='".$privilegios[$i]["Enlace"]."'";
	   $option = "<div class='privilegioMenu' onclick=$link>".$privilegios[$i]['Texto']."</div>". $option;
   } 
   echo $option;
 ?>
</div>
</div>
<br />


<table style="width:75%;top:38px;margin: 0 auto;position:relative;" border="0">
 <tr>
 <td>
 <div class="contenedorPrincipal">
<form id='formValidado' name='formValidado' method='post' action='nuevo_cargo.php' enctype='multipart/form-data'>
<table width='100%' border='0' align='center' cellpadding='4' cellspacing='3'>
<tr>
  <td colspan='5' align='center' >
    
  <table cellpadding='0' cellspacing='0' width='100%'>
    <tr class='cabeceraInicialListar'> 
      <td height="92" colspan='2' >&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="button" value="Generar" class="botonseycon" onclick="realizarConsulta()" />
        
        
        </td>
  <td></td>
  <td colspan="3" >
  <div >
  <table width="100%" border="0">
    <tr>
      <td width="13%" align="right">Periodo:</td>
      <td width="24%">
        <select id="mes"  style="width:80%" onchange="realizarConsulta2();">
          <option value="0">-- Seleccione --</option>
          <option value="1">Enero</option>
          <option value="2">Febrero</option>
          <option value="3">Marzo</option>
          <option value="4">Abril</option>
          <option value="5">Mayo</option>
          <option value="6">Junio</option>
          <option value="7">Julio</option>
          <option value="8">Agosto</option>
          <option value="9">Septiembre</option>
          <option value="10">Octubre</option>
          <option value="11">Noviembre</option>
          <option value="12">Diciembre</option>
          </select>
        </td>
      <td width="16%">
        <select id="anio" name="anio" onchange="realizarConsulta2();" style="width:80px">
          <?php
	 for ($i=2010;$i<=2025;$i++){
       echo "<option value='$i'>$i</option>";
	 }
	?>
          </select>
        </td>
      <td width="11%" align="right">Sucursal:</td>
      <td width="30%"><select name="sucursal" id="sucursal" style="width:80%;" onchange="realizarConsulta2();">
        <option value="0" selected="selected">-- Seleccione --</option>
        <?php
   $sql = "select idsucursal,left(nombrecomercial,25)as 'nombrecomercial' from sucursal where estado=1;";
   $db->imprimirCombo($sql);
   ?>
        </select></td>
      <td width="4%"></td>
      <td width="2%">&nbsp;</td>
      </tr>
  </table>
    
  </div>
  </td> 
      </tr>
    
  </table>
    
    
  </td>
</tr>

<tr>
  <td colspan="5">
  <table width="100%" height="289" >
    <tr>
      <td width="80" valign="top">
      
      <div class="session2_lateral">
      <table width="100%" border="0">
  <tr>
    <td colspan="2" class="session2_titulo_lateral">Datos del Bono</td>
    </tr>
  <tr>
    <td width="40">&nbsp;</td>
    <td width="100">&nbsp;</td>
  </tr>
  <tr>
    <td align="right">Nº</td>
    <td><input type="text" id="nro" name="nro"  style="width:80%" disabled="disabled"/></td>
  </tr>
  <tr>
    <td colspan="2" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="center">Bono de Prod.</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="text" id="bonoproduccion" name="bonoproduccion"  style="width:80%" onkeypress="return soloNumeros(event);"/></td>
  </tr>
  <tr>
    <td colspan="2" align="center">Horas Extras</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="text" id="horasextras" name="horasextras"  style="width:80%" onkeypress="return soloNumeros(event);"/></td>
  </tr>
  <tr>
    <td colspan="2" align="center">Transporte</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="text" id="transporte" name="transporte"  style="width:80%" onkeypress="return soloNumeros(event);"/></td>
  </tr>
  <tr>
    <td colspan="2" align="center">Puntualidad</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="text" id="puntualidad" name="puntualidad"  style="width:80%" onkeypress="return soloNumeros(event);"/></td>
  </tr>
  <tr>
    <td colspan="2" align="center">Comisión</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="text" id="comision" name="comision"  style="width:80%" onkeypress="return soloNumeros(event);"/></td>
  </tr>
  <tr>
    <td colspan="2" align="center">Asistencia</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="text" id="asistencia" name="asistencia"  style="width:80%" onkeypress="return soloNumeros(event);"/></td>
  </tr>
    <tr>
      <td  colspan="2" align="center">&nbsp;</td>
    </tr>
    <tr>
      <td  colspan="2" align="center">&nbsp;</td>
    </tr>
    <tr>
      <td  colspan="2" align="center">&nbsp;</td>
    </tr>
    <tr>
    <td  colspan="2" align="center"><input type="hidden" id="idbono" name="idbono"  />
    <input type="button" value="Guardar" class="botonNegro" onclick="registrarBono()"/>
    </td>
  </tr>
    <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

      
      </div>
      
      
      </td>
      <td width="500" valign="top">
      
      <div class="session2_contenedor">
       <table width="100%" cellpadding="0" cellspacing="1">
  <tr class="session2_cabecera1">
    <td colspan="2" rowspan="2" >Nº</td>
    <td rowspan="2" >Nombre</td>
    <td width="66" rowspan="2">Fecha de Ingreso</td>
    <td width="60" rowspan="2" >Sueldo Básico</td>
    <td width="65" rowspan="2" >Bono de Prod.</td>
    <td width="50" rowspan="2" >Horas Extras</td>
    <td colspan="4" >OTROS BONOS</td>
    </tr>
  <tr class="session2_cabecera1">
    <td width="69" >Transporte</td>
    <td width="75" >Puntualidad</td>
    <td width="57" >Comisión</td>
    <td width="63" >Asistencia</td>
  </tr>
   <tbody id="detalleBonos">
   
   </tbody>
  
</table>

      </div>     
      
      </td>
    </tr>
  </table>
</td>
</tr>
</table>
</form>
</div>

</td></tr></table>
<br />
<br />
<script>
  seleccionarCombo("anio","<?php echo date("Y");?>");
</script>


<!-- InstanceEndEditable -->
  
  <!-- end .footer -->

</div>
 <div class="footerAdm">
  <div class="logo1"></div>
  <div class="logo2"></div>
  <div class="logo3"></div>
  <div class="textoPie1">Seycon 3.0 - Diseñado y Desarrollado por:  Jorge G. Eguez Soliz </div>
  <div class="textoPie2">Copyright &copy; Consultora Guez S.R.L</div>
 </div>

</body>

<!-- InstanceEnd --></html>