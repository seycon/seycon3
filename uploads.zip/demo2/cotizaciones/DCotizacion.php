<?php
session_start();
include("../conexion.php");
include("../aumentaComa.php");
$db = new MySQL();
$tipo = $_GET['transaccion'];
if (!isset($_SESSION['softLogeoadmin'])){
  header("Location: ../index.php");	
}


function filtro($cadena){
  return htmlspecialchars(strip_tags($cadena),ENT_QUOTES);	
}

if ($tipo == "consulta"){	
	$consulta = "select * from producto WHERE idproducto =".$_GET['codigo'];
	$respuesta = $db->arrayConsulta($consulta);
	echo $respuesta['stockactual']."---";
	echo $respuesta[$_GET['tipoprecio']]."---";
	exit();
}

if ($tipo == "insertar"){
	$fecha = filtro($db->GetFormatofecha($_GET['fecha'],"/"));
	$tiempoentrega = filtro($db->GetFormatofecha($_GET['tiempoentrega'],"/"));
	$tiempocredito = filtro($_GET['tiempocredito']);
	$sql = "insert into cotizacion values(null,'".filtro($_GET['cliente'])."','$fecha','".filtro($_GET['descuento'])."','".filtro($_GET['recargo'])."','".
	filtro($_GET['moneda'])."','".filtro($_GET['glosa'])."','".filtro($_GET['formadepago'])."','$tiempoentrega','$tiempocredito','".filtro($_GET['validez'])."','".
	filtro($_GET['contacto'])."','".filtro($_GET['monto'])."','".filtro($_GET['almacen'])."','".filtro($_GET['tipocambio'])."',$_SESSION[id_usuario],1)";
	$db->consulta($sql);
	$codigo = $db->getMaxCampo("idcotizacion","cotizacion");
	$datos =  json_decode(stripcslashes($_GET['detalle']));  			
	  for ($i=0;$i<count($datos);$i++){
		$fila = $datos[$i];                 
		$id = filtro($fila[0]);
		$cantidad = filtro($fila[1]);
		$precio = filtro(desconvertir($fila[2]));
		$total = filtro(desconvertir($fila[3]));
		$consulta = "insert into detallecotizacion values('$id','$codigo','$cantidad','$precio','$total');";
		$db->consulta($consulta);				
	  }	
	echo $codigo."---";  
	$sql = "select cotimprimir from impresion;";  
	$dato = $db->arrayConsulta($sql);
	echo $dato['cotimprimir']."---";	
	exit();  
}

if ($tipo == "modificar"){
  $cotizacion = $_GET['idcotizacion'];
  $fecha = $db->GetFormatofecha($_GET['fecha'],"/");
  $tiempoentrega = $db->GetFormatofecha($_GET['tiempoentrega'],"/");
  $tiempocredito = $_GET['tiempocredito'];
  $sql = "update cotizacion set fecha='$fecha',moneda='".filtro($_GET['moneda'])."',idalmacen='".filtro($_GET['almacen'])."',idcliente='".filtro($_GET['cliente'])."',contacto='".filtro($_GET['contacto'])."',glosa='".filtro($_GET['glosa'])."',monto='".filtro(desconvertir($_GET['monto']))."',idusuario=".$_SESSION['id_usuario'].",descuento='".filtro($_GET['descuento'])."',recargo='".filtro($_GET['recargo'])."'
  ,formapago='".filtro($_GET['formadepago'])."',tiempoentrega='".$tiempoentrega."',tiempocredito='$tiempocredito',validez='".
  filtro($_GET['validez'])."',tipocambio='".filtro($_GET['tipocambio'])."' where idcotizacion=$cotizacion;";  	
  $db->consulta($sql);
  $sql = "delete from detallecotizacion where idcotizacion=$cotizacion";
  $db->consulta($sql);
  $datos =  json_decode(stripcslashes($_GET['detalle']));
  			
	  for ($i=0;$i<count($datos);$i++){
		$fila = $datos[$i];                 
		$id = filtro($fila[0]);
		$cantidad = filtro($fila[1]);
		$precio = filtro(desconvertir($fila[2]));
		$total = filtro(desconvertir($fila[3]));
		$consulta = "insert into detallecotizacion values('$id',$cotizacion,'$cantidad','$precio','$total');";
		$db->consulta($consulta);				
	  }
	echo $cotizacion."---";  
	$sql = "select cotimprimir from impresion;";  
	$dato = $db->arrayConsulta($sql);
	echo $dato['cotimprimir']."---";		
	exit();  
}

?>

