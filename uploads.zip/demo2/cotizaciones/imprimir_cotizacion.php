<?php
session_start();
if (!isset($_SESSION['softLogeoadmin'])){
       header("Location: ../index.php");	
}
ob_start();
include("../MPDF53/mpdf.php");
include("../conexion.php");
include('../reportes/literal.php');
$db = new MySQL();


$logo = $_GET['logo'];
$sql = "select imagen,left(nombrecomercial,13)as 'nombrecomercial',nit from empresa;";
$datoGeneral = $db->arrayConsulta($sql);

$idcotizacion=$_GET['idcotizacion'];

$sql = "select t.nombrenit,t.direccionoficina,t.telefono, 
c.contacto,c.tipocambio,c.moneda,date_format(c.fecha,'%d/%m/%Y')as 'fecha',left(s.nombrecomercial,25)as 'nombrecomercial',
c.validez,c.tiempoentrega,c.formapago,c.descuento,left(c.glosa,80)as 'glosa',left(concat(b.nombre,' ',b.apellido),40)as 'usuario'
from cotizacion c,cliente t,trabajador b,usuario u,almacen a,sucursal s 
where t.idcliente=c.idcliente
and c.idalmacen=a.idalmacen 
and a.sucursal=s.idsucursal 
and c.idusuario=u.idusuario
and u.idtrabajador=b.idtrabajador
and c.idcotizacion=$idcotizacion;";
$cotizacion = $db->arrayConsulta($sql);

$sql = "select p.idproducto,p.nombre,round(ds.precio,2)as 'precio',ds.cantidad,
	    round(ds.total,2)as 'total' from detallecotizacion ds,producto p,cotizacion s
        where ds.idcotizacion=s.idcotizacion and ds.idproducto=p.idproducto and s.idcotizacion=$idcotizacion";
$detalleCotizacion = $db->consulta($sql);

$numCotizacion = 0;	
$totalCotizacion = 0;	

function datosGenerales($dato){
  echo "<table width='100%' border='0'>
  <tr>
    <td width='12%' class='session2_titulos'>Empresa:</td>
    <td width='53%' class='session2_titulosDatos'>$dato[nombrenit]</td>
    <td width='22%' class='session2_titulos'>Fecha:</td>
    <td width='13%' class='session2_titulosDatos'>$dato[fecha]</td>
  </tr>
  <tr>
    <td class='session2_titulos'>Contacto:</td>
    <td class='session2_titulosDatos'>$dato[contacto]</td>
    <td class='session2_titulos'>Moneda:</td>
    <td class='session2_titulosDatos'>$dato[moneda]</td>
  </tr>
  <tr>
    <td class='session2_titulos'>Dirección:</td>
    <td class='session2_titulosDatos'>$dato[direccionoficina]</td>
    <td class='session2_titulos'>T.C.:</td>
    <td class='session2_titulosDatos'>$dato[tipocambio]</td>
  </tr>
  <tr>
    <td class='session2_titulos'>Teléfono:</td>
    <td class='session2_titulosDatos'>$dato[telefono]</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>";
}

function insertarFila($num,$dato,$total){
 $total = $total + $dato['total'];	
  echo " <tr>
    <td class='session3_datos1'>$num</td>
    <td class='session3_datos1_1' align='left'>$dato[nombre]</td>
    <td class='session3_datos1_1'>$dato[cantidad]</td>
    <td class='session3_datos1_1'>".number_format($dato['precio'],2)."</td>
    <td class='session3_datos1_2'>".number_format($dato['total'],2)."</td>
  </tr>";	
  return $total;
}

function insertarTotal($total,$descuento){
  $liquido = $total - $descuento;	
  echo "<tr>
    <td class='session3_contornoSuperior'>&nbsp;</td>
    <td class='session3_contornoSuperior'>&nbsp;</td>
    <td class='session3_contornoSuperior'>&nbsp;</td>
    <td class='session3_textoTotal1'>Sub Total:</td>
    <td class='session3_subtotal'>".number_format($total,2)."</td>
  </tr>
  <tr>
    <td align='right' class='session3_montoLiteral'>Son:</td>
    <td colspan='2' class='session3_montoLiteral'>".NumerosALetras($liquido)."</td>
    <td class='session3_textoTotal2'>Descuento:</td>
    <td class='session3_subtotal_dato'>".number_format($descuento,2)."</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td class='session3_textoTotal2'>TOTAL Bs.:</td>
    <td class='session3_subtotal_dato2'>".number_format($liquido,2)."</td>
  </tr>";	
}

function insertarSession4($dato){
 echo "<table width='100%' border='0'>
  <tr>
    <td width='26%' class='session3_tituloFinales'>Validez de la Propuesta:</td>
    <td width='74%' class='session3_montoLiteral'>$dato[validez]</td>
  </tr>
  <tr>
    <td class='session3_tituloFinales'>Tiempo de Entrega:</td>
    <td class='session3_montoLiteral'>$dato[tiempoentrega]</td>
  </tr>
  <tr>
    <td class='session3_tituloFinales'>Forma de Pago:</td>
    <td class='session3_montoLiteral'>$dato[formapago]</td>
  </tr>
</table>";	
}

function insertarGlosa($dato){
 echo "<table width='100%' border='0'>
  <tr>
    <td width='10%'>&nbsp;</td>
    <td width='90%'>&nbsp;</td>
  </tr>
  <tr>
    <td class='session3_tituloFinales'>GLOSA:</td>
    <td class='session3_glosa'>$dato[glosa]</td>
  </tr>
</table>";	
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="cotizacion.css" type="text/css" />
<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
<title>Reporte de Cotizacion</title>

</head>

<body>


<div class="borde"></div>
<div class="session1_numTransaccion">
 <table width="100%" border="0">
      <tr><td align="center" height="3"></td></tr> 
     <tr><td class="session1_titulo_num"><?php echo "Nº $idcotizacion"; ?></td></tr> 
    </table>
</div>
<div class="session1_sucursal">
    <table width="100%" border="0">
      <tr><td align="center" class="session1_tituloSucursal"><?php 	  
	 	  echo strtoupper($cotizacion['nombrecomercial']); ?></td></tr>
    </table>
</div>
<div class="session1_logotipo"><?php if ($logo == 'true'){ echo  "<img src='../$datoGeneral[imagen]' width='200' height='70'/>";} ?></div>
<div class="session1_contenedorTitulos">
   <table width="100%" border="0">
     <tr><td align="center" class="session1_titulo1">COTIZACION</td></tr> 
    </table>
</div>

<div class="session2_datosPersonales">
<?php datosGenerales($cotizacion); ?>
</div>

<div class="session3_datos">
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center"> 
  <tr>
    <td width="5%" class="session3_titulosCabecera2">Nº</td>
    <td width="60%" class="session3_titulosCabecera">Descripción</td>
    <td width="12%" class="session3_titulosCabecera">Cantidad</td>
    <td width="11%" class="session3_titulosCabecera">P/U</td>
    <td width="12%" class="session3_titulosCabecera">Total</td>
  </tr>
 
 <?php
   
   while($dato = mysql_fetch_array($detalleCotizacion)){
	   $numCotizacion++;
	   $totalCotizacion = insertarFila($numCotizacion,$dato,$totalCotizacion);
	   
   }
   insertarTotal($totalCotizacion,$cotizacion['descuento']);
 
 ?>  
</table>

<?php
  insertarSession4($cotizacion);
   insertarGlosa($cotizacion);
?>


</div>


<div class="session4_pieFirma"> 
 <table width="93%" border="0" align="center">
  <tr>
    <td width="173">&nbsp;</td>
    <td width="231" class="session4_bordeFirma"></td>
    <td width="97">&nbsp;</td>
    <td width="193" class="session4_bordeFirma"></td>
    <td width="97">&nbsp;</td>
    <td width="191" class="session4_bordeFirma"></td>
    <td width="246">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="center" style="font-weight:bold">Elaborado Por</td>
    <td>&nbsp;</td>
    <td align="center" style="font-weight:bold">Vo.Bo.</td>
    <td>&nbsp;</td>
    <td align="center" style="font-weight:bold">Cliente</td>
    <td>&nbsp;</td>
  </tr>
</table> 
 </div>
 
  <div class="session4_pie"> 
  <table width="93%" border="0" align="center">
  <tr>
    <td width="120" align="right">Elaborado por:</td>
    <td width="324"><?php echo $cotizacion['usuario'];?></td>
    <td width="93">&nbsp;</td>
    <td width="189">&nbsp;</td>
    <td width="201">&nbsp;</td>
    <td width="170" >Impreso: <?php echo date("d/m/Y");?></td>
    <td width="130">Hora: <?php echo date("H:i:s");?></td>
  </tr>
  </table>
 </div> 


</body>
</html>
<?php
$mpdf=new mPDF('utf-8','Letter'); 
$content = ob_get_clean();
$mpdf->WriteHTML($content);
$mpdf->Output();
exit;
?>