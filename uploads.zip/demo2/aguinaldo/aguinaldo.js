// JavaScript Document

var servidor = "aguinaldo/Daguinaldo.php";

 var $$ = function(id){
  return document.getElementById(id);	 
 }

var ajax = function(){
  return (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP"
  ); 	
}


function consultar(parametros,funcion){
 var  pedido = ajax();	
 filtro = parametros; 
 pedido.open("GET",servidor+"?"+filtro,true);
   pedido.onreadystatechange = function(){
	   if (pedido.readyState == 4){     	
          var resultado = pedido.responseText; 
    	  funcion(resultado);   
	   }	   
   }
   pedido.send(null);
}


function registrarAguinaldo(){
  if ($$("idtrabajador").value != ""){
	$$("meses").value = ($$("meses").value == "") ? 0 : $$("meses").value;  
	$$("dias").value = ($$("dias").value == "") ? 0 : $$("dias").value;  	

    var parametros = "transaccion=insertar&idtrabajador="+$$("idtrabajador").value+"&gestion="+$$("anio").value
    +"&meses="+$$("meses").value+"&dias="+$$("dias").value;	
    consultar(parametros,actualizarTabla);
  }
  else{
	alert("Señor Usuario Debe Seleccionar un Item de la Lista");  
  }
}

function realizarConsulta(){
  var parametros = "transaccion=consulta&anio="+$$("anio").value+"&sucursal="+$$("sucursal").value;
  if ( $$("anio").value != "" && $$("sucursal").value != "0"){
   consultar(parametros,cargarItemTabla);
  }
}

function actualizarTabla(resultado){
   var numero = $$("nro").value;	
   $$("detalleBonos").rows[numero-1].cells[5].innerHTML = $$("meses").value;
   $$("detalleBonos").rows[numero-1].cells[6].innerHTML = $$("dias").value;
   var base =desconvertirFormatoNumber($$("detalleBonos").rows[numero-1].cells[4].innerHTML);
   var opt1 = ($$("meses").value == 0) ? 0 : ((base /12) *($$("meses").value));
   var opt2 = ($$("dias").value == 0) ? 0 : ((base / 360) * ($$("dias").value));
   var liquido = opt1 + opt2;
   $$("detalleBonos").rows[numero-1].cells[7].innerHTML = liquido.toFixed(2);
   $$("nro").value = "";
   $$("meses").value = "";
   $$("dias").value = "";  
}

function cargarItemTabla(lista){
	$$("detalleBonos").innerHTML = lista;
}

function recuperarDatos(numero,idtrabajador){
   $$("nro").value = numero;	
   $$("idtrabajador").value = idtrabajador;
   $$("meses").value = $$("detalleBonos").rows[numero-1].cells[5].innerHTML;
   $$("dias").value = $$("detalleBonos").rows[numero-1].cells[6].innerHTML;   
}