<?php
	session_start();
	include("../conexion.php");
	$db = new MySQL();
	$tipo = $_GET['transaccion'];

	if (!isset($_SESSION['softLogeoadmin'])) {
		   header("Location: ../index.php");	
	}
	
	if ($tipo == "trabajadores") {
	   $idsucursal = $_GET['idsucursal']; 
	   $sql = "select idtrabajador,left(concat(nombre,' ',apellido),20)as 'nombre' from trabajador 
	   where estado=1 and idsucursal=$idsucursal;";
	   echo "<option value=''> -- Seleccione -- </option>";
	   $db->imprimirCombo($sql);
	   exit(); 
	}
	
	if ($tipo == "sueldo") {
	  $idtrabajador = $_GET['idtrabajador'];
	  $sql = "select * from trabajador where idtrabajador=$idtrabajador";
	  $dato = $db->arrayConsulta($sql);
	  echo  number_format($dato['sueldobasico'],2);  
	  exit();
	}

?>