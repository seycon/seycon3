// JavaScript Document

var servidor = "anticipo/DAnticipo.php";


 var $$ = function(id){
  return document.getElementById(id);	 
 }

var ajax = function(){
  return (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP"
  ); 	
}

function consultar(parametros,funcion){
 var  pedido = ajax();	
 filtro = parametros; 
 pedido.open("GET",servidor+"?"+filtro,true);
   pedido.onreadystatechange = function(){
	   if (pedido.readyState == 4){     	
          var resultado = pedido.responseText; 
     	  funcion(resultado);   
	   }	   
   }
   pedido.send(null);
}

function consultarTrabajadores(){
  var parametros = "";
   if ($$("idsucursal").value != "" ){
	  parametros = "transaccion=trabajadores&idsucursal=" + $$("idsucursal").value; 
	  consultar(parametros,cargarTrabajadores);
   }
}

function cargarTrabajadores(resultado){
 	$$("idtrabajador").innerHTML = resultado;
}

function cargarSueldo(resultado){
	$$("sueldobasico").value = resultado;
}

function consultarSueldo(){
  var parametros = "";
    if ($$("idtrabajador").value != ""){
	   parametros = "transaccion=sueldo&idtrabajador=" + $$("idtrabajador").value; 	
	   consultar(parametros,cargarSueldo);
	}
}

 var seleccionarCombo = function(combo,opcion){	 
	 var cb = document.getElementById(combo);
	 for (var i=0;i<cb.length;i++){
		if (cb[i].value==opcion){
		cb[i].selected = true;
		break;
		}
	 }	 
 }

function soloNumeros(evt){
var tecla = (document.all) ? evt.keyCode : evt.which;
return ((tecla>47 && tecla<58)|| tecla == 8 || tecla == 0 || tecla == 46);
}
