// JavaScript Document

var servidor = "bonos/DBonos.php";

 var $$ = function(id){
  return document.getElementById(id);	 
 }

var ajax = function(){
  return (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP"
  ); 	
}


function consultar(parametros,funcion){
 var  pedido = ajax();	
 filtro = parametros; 
 pedido.open("GET",servidor+"?"+filtro,true);
   pedido.onreadystatechange = function(){
	   if (pedido.readyState == 4){     	
          var resultado = pedido.responseText; 
    	  funcion(resultado);   
	   }	   
   }
   pedido.send(null);
}


function registrarBono(){
  if ($$("idbono").value != ""){
	$$("bonoproduccion").value = ($$("bonoproduccion").value == "") ? 0 : $$("bonoproduccion").value;  
	$$("horasextras").value = ($$("horasextras").value == "") ? 0 : $$("horasextras").value;  	
	$$("transporte").value = ($$("transporte").value == "") ? 0 : $$("transporte").value;  
	$$("puntualidad").value = ($$("puntualidad").value == "") ? 0 : $$("puntualidad").value; 
	$$("comision").value = ($$("comision").value == "") ? 0 : $$("comision").value; 
	$$("asistencia").value = ($$("asistencia").value == "") ? 0 : $$("asistencia").value; 
    var parametros = "transaccion=insertar&idbono="+$$("idbono").value+"&bonoproduccion="+$$("bonoproduccion").value
    +"&horasextras="+$$("horasextras").value+"&transporte="+$$("transporte").value+"&puntualidad="+$$("puntualidad").value
    +"&comision="+$$("comision").value+"&asistencia="+$$("asistencia").value;	
    consultar(parametros,actualizarTabla);
  }
  else{
	alert("Señor Usuario Debe Seleccionar un Item de la Lista");  
  }
}

function realizarConsulta(){
  var parametros = "transaccion=consulta&anio="+$$("anio").value+"&mes="+$$("mes").value+"&sucursal="+$$("sucursal").value;
  if ( $$("anio").value != "" && $$("mes").value != "0" && $$("sucursal").value != "0"){
   consultar(parametros,cargarItemTabla);
  }
}

function realizarConsulta2(){
  var parametros = "transaccion=consulta2&anio="+$$("anio").value+"&mes="+$$("mes").value+"&sucursal="+$$("sucursal").value;
  if ( $$("anio").value != "" && $$("mes").value != "0" && $$("sucursal").value != "0"){
   consultar(parametros,cargarItemTabla);
  }
}

function actualizarTabla(resultado){
   var numero = $$("nro").value;	
   $$("detalleBonos").rows[numero-1].cells[5].innerHTML = convertirFormatoNumber(parseFloat($$("bonoproduccion").value).toFixed(2));
   $$("detalleBonos").rows[numero-1].cells[6].innerHTML = $$("horasextras").value;
   $$("detalleBonos").rows[numero-1].cells[7].innerHTML = convertirFormatoNumber(parseFloat($$("transporte").value).toFixed(2));
   $$("detalleBonos").rows[numero-1].cells[8].innerHTML = convertirFormatoNumber(parseFloat($$("puntualidad").value).toFixed(2));
   $$("detalleBonos").rows[numero-1].cells[9].innerHTML = convertirFormatoNumber(parseFloat($$("comision").value).toFixed(2));
   $$("detalleBonos").rows[numero-1].cells[10].innerHTML= convertirFormatoNumber(parseFloat($$("asistencia").value).toFixed(2));
   $$("nro").value = "";
   $$("bonoproduccion").value = "";
   $$("horasextras").value = "";
   $$("transporte").value = "";
   $$("puntualidad").value = "";
   $$("comision").value = "";
   $$("asistencia").value = "";
}

function cargarItemTabla(lista){
	$$("detalleBonos").innerHTML = lista;
}

function recuperarDatos(numero,idcargo){
   $$("nro").value = numero;	
   $$("idbono").value = idcargo;
   $$("bonoproduccion").value = desconvertirFormatoNumber($$("detalleBonos").rows[numero-1].cells[5].innerHTML);
   $$("horasextras").value = $$("detalleBonos").rows[numero-1].cells[6].innerHTML;
   $$("transporte").value = desconvertirFormatoNumber($$("detalleBonos").rows[numero-1].cells[7].innerHTML);
   $$("puntualidad").value = desconvertirFormatoNumber($$("detalleBonos").rows[numero-1].cells[8].innerHTML);
   $$("comision").value = desconvertirFormatoNumber($$("detalleBonos").rows[numero-1].cells[9].innerHTML);
   $$("asistencia").value = desconvertirFormatoNumber($$("detalleBonos").rows[numero-1].cells[10].innerHTML);
}