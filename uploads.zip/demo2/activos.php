<?php

if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/templateactivo.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<script type="text/javascript" src="js/submenus.js"></script>

<script type="text/javascript"> 
$(document).ready(function(){
 
	$("ul.submenu").parent().append("<span></span>"); 	
	$("ul.menu li span").click(function() { //Al hacer click se ejecuta...
		
		//Con este codigo aplicamos el movimiento de arriva y abajo para el submenu
		$(this).parent().find("ul.submenu").slideDown('fast').show(); //Menu desplegable al hacer click 
		$(this).parent().hover(function() {
		}, function(){	
			$(this).parent().find("ul.submenu").slideUp('slow'); //Ocultamos el submenu cuando el raton sale fuera del submenu
		});
 
		}).hover(function() { 
			$(this).addClass("subhover"); //Agregamos la clase subhover
		}, function(){	//Cunado sale el cursor, sacamos la clase
			$(this).removeClass("subhover"); 
	});
	
	$("ul.menuH li span").click(function() { //Al hacer click se ejecuta...
		
		//Con este codigo aplicamos el movimiento de arriva y abajo para el submenu
		$(this).parent().find("ul.submenu").slideDown('fast').show(); //Menu desplegable al hacer click
 
		$(this).parent().hover(function() {
		}, function(){	
			$(this).parent().find("ul.submenu").slideUp('slow'); //Ocultamos el submenu cuando el raton sale fuera del submenu
		});
 
		}).hover(function() { 
			$(this).addClass("subhover"); //Agregamos la clase subhover
		}, function(){	//Cunado sale el cursor, sacamos la clase
			$(this).removeClass("subhover"); 
	});
 
});
</script>
<!-- InstanceBeginEditable name="doctitle" -->
<title>Sistema Empresarial y Contable – Seycon 2011</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
 <link href="SpryAssets/SpryAccordion.css" rel="stylesheet" type="text/css" /> 
</head> 

<body >

<div class="franjaCabecera">
<div class="franjaInicial"></div>
<div class="alineadorFrontalSeycon">

<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td > 
    <div class="headerPrincipal">
       <div class="logoEmpresa"></div>
        
          <div class="tituloEmpresa"><?php echo "Sistema Empresarial y Contable";?></div>
          <div class="nitEmpresa"> 
		  <?php 
              $cadenaNit = $_SESSION['nit'];
			  if (strlen($cadenaNit) > 15)	{			  
				  $cadenaNit = substr($cadenaNit,0,15);
			  }
              $cadena = $_SESSION['nombreEmpresa'];
			  if (strlen($cadena) > 35) {				  
				  $cadena = substr($cadena,0,35);
			  }  
              echo $cadena." - ".$cadenaNit;
          ?>
          </div>
      </div>
    </td>
  </tr>
  <tr>
    <td >
     <div class="menu2"></div>
    </td>
  </tr>
</table>
  <div class="contenedorMenuFrontal">
   <ul class="menu"> 
            <li> 
                <a href="#">Inventario</a>
                <?php 
					  $estructura = $_SESSION['estructura'];
					  $menus = $estructura['Inventario'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Inventario&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?>
            </li> 
            <li> 
                <a href="#">Recursos</a> 
                <?php 
					  $menus = $estructura['Recursos'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Recursos&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?>
            </li>
            <li> 
                <a href="#">Activos</a> 
                <?php 
					  $menus = $estructura['Activo'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Activo&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?>
            </li> 
             <li> 
                <a href="#">Ventas</a> 
                <?php 
					  $menus = $estructura['Ventas'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Ventas&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?> 
            </li> 
             <li> 
                <a href="#">Contabilidad</a> 
                <?php 
					  $menus = $estructura['Contabilidad'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Contabilidad&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?> 
            </li> 
             <li> 
                <a href="#">Agenda</a> 
                <?php 
					  $menus = $estructura['Agenda'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Agenda&opt=$titulo'>".$titulo."</a></li>";
						 }
						 echo "</ul>";
					   }
				 ?>  
            </li>  
        </ul> 
  
  
       
           <div class="usuarioSistema">
            <div class="borde1Usuario"></div>
            <div class="borde2Usuario">
               <div class="sessionHerramienta">
               <ul class="menuH"> 
                 <li> 
                 <?php 
					  $estructura = $_SESSION['estructura'];
					  $menus = $estructura['Administracion'];
					   if ($menus != "") {
						 echo  "<ul class='submenu'>"; 
						 for ($i = 0; $i < count($menus); $i++) {
						     $titulo = $menus[$i]['Menu']; 
						     echo "<li><a href='redireccion.php?mod=Administracion&opt=$titulo'>".$titulo."</a></li>";
						 }
						  echo "<li><a href='cerrar.php'>Salir</a></li>";
						 echo "</ul>";
					   }
				 ?>
            </li>
               
               </ul>
               </div>
               <div class="nombreUsuario">
            <?php
            $cadena = $_SESSION['nombre_usuario'];
              if (strlen($cadena) > 15) {				  
                $cadena = substr($cadena,0,15);
			  }
            echo ucfirst($cadena);				
            ?> </div>
            </div>
          </div> 
         
    </div>       
   </div>  
</div>

<div class="container">

  <!-- InstanceBeginEditable name="Regioneditable" -->
   <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="right">&nbsp;</p>
  <p align="right">&nbsp;</p>
  <p align="right">&nbsp;</p>
  <p align="right">&nbsp;</p>
  <p align="right">&nbsp;</p>
  <p align="right">&nbsp;</p>
  <p align="right"><img src="images/logoseycongrande.png" width="550" height="200" alt="logoseycon" /></p>
  
  <!-- InstanceEndEditable -->
  
  <!-- end .footer -->

</div>
 <div class="footerAdm">
  <div class="logo1"></div>
  <div class="logo2"></div>
  <div class="logo3"></div>
  <div class="textoPie1">Seycon 3.0 - Diseñado y Desarrollado por:  Jorge G. Eguez Soliz </div>
  <div class="textoPie2">Copyright &copy; Consultora Guez S.R.L</div>
 </div>

</body>

<!-- InstanceEnd --></html>
