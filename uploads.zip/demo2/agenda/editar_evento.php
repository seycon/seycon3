<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
    <div>
        <table border="0" align="center">
          <tr>
            <td align="right">Titulo:</td>
            <td> 
              <input type="text" name="titulo" id="titulo" />
             </td>
          </tr>
          <tr>
            <td align="right" valign="top">Descripcion:</td>
            <td> 
              <textarea name="descripcion" id="descripcion" cols="45" rows="5"></textarea>
             </td>
          </tr>
          <tr>
            <td align="right">Fecha Evento:</td>
            <td> 
              <input type="text" name="fechaevento" id="fechaevento" />
             </td>
          </tr>
          <tr>
            <td align="right">URL:</td>
            <td> 
              <input type="text" name="url" id="url" />
             </td>
          </tr>
          <tr>
            <td align="right">Organizador:</td>
            <td> 
              <input type="text" name="organizador" id="organizador" />
             </td>
          </tr>
          <tr>
            <td align="right">Inicio:</td>
            <td> 
              <input type="text" name="inicio" id="inicio" />
             </td>
          </tr>
          <tr>
            <td align="right">Fin:</td>
            <td> 
              <input type="text" name="fin" id="fin" />
             </td>
          </tr>
          <tr>
            <td align="right">Lugar:</td>
            <td> 
              <input type="text" name="lugar" id="lugar" />
             </td>
          </tr>
          <tr>
            <td align="right"></td>
            <td> 
              <input type="submit" name="aceptar" id="aceptar" value="Aceptar" />
             </td>
          </tr>
        </table>

</div>
</body>
</html>