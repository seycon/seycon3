<?php
  session_start();
  $estructura = $_SESSION['estructura'];
  $menus = $estructura['Inventario'];
 
   
   
   function getOpciones($menus, $casoUso) {
	   $optionesGenerales = array();
	   for ($i = 0; $i < count($menus); $i++) {
		   $optionMenu = $menus[$i]['Menu'];
	   	   $submenus = $menus[$i]['Submenu'];
		   if ($optionMenu == $casoUso) {
			   for ($j = 0; $j < count($submenus); $j++) {				   
				   $option = array("Enlace" => $submenus[$j]['Enlace'], "Texto" => $submenus[$j]['Texto']);
				   array_push($optionesGenerales,$option);
			   }
			   return $optionesGenerales;
		   }
	   }
	   return $optionesGenerales;
   }


   $privilegios = getOpciones($menus, "Ingresar Productos");
   
   for ($i = 0; $i < count($privilegios); $i++) {
        echo $privilegios[$i]["Enlace"].">".$privilegios[$i]["Texto"]."<br>";   
   }

?>