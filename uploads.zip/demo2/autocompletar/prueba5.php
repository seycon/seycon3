<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<script language="javascript">

  function imprSelec(nombre)

  {
  
  var ficha = document.getElementById(nombre);

  var ventimp = window.open(' ', 'popimpr');

  ventimp.document.write( ficha.innerHTML );

  ventimp.document.close();

  ventimp.print( );

  ventimp.close();

  } 

</script> 
<link rel="stylesheet" href="../css/jquery-ui-1.8.13.custom.css" type="text/css"/>
<script src="../js/jquery-1.5.1.min.js"></script>
<script src="../js/jquery-ui-1.8.13.custom.min.js"></script>
<script src="../js/ui/i18n/jquery.ui.datepicker-es.js"></script>

<style type="text/css" >
.borde1Usuario{
  position: absolute;
  top: 1px;
  left: 1px;
  width: 180px;
  height: 32px;   
  background-color: #000;
  opacity:.50;
  -moz-opacity: 0.50;
  filter: alpha(opacity=50);
  z-index:300;
  border-radius:14px;
  -moz-border-radius:14px;
  -webkit-border-radius:14px;
  -khtml-border-radius:14px;
  box-shadow: 1px 0.5px 2px #000;
  -webkit-box-shadow: 1px 0.5px 2px #000;
  -moz-box-shadow: 1px 0.5px 2px #000;
  filter: shadow(color=#000, direction=135, strength=2); 	
}

.borde2Usuario{
  position:absolute;
  top:5.8px;
  left:5px;
  width:138px;
  height:20px;   
  color:#FFF;
  background-color:#000;
  z-index:311;
  border-radius: 10px;
  -moz-border-radius:10px ;
  -webkit-border-radius: 10px;
  -khtml-border-radius: 10px;
  border:0px;
  padding-right:28px;
  padding-left:6px;  
}

.contenedorSearch{
  position:absolute;
  left:100px;
  top:40px;	
}

.iconSearch{
  position:absolute;
  left:155px;
  top:6px;
  width:22px;
  height:22px;
  background:#FFF;	
  z-index:315;
  color:#fff;
  border-radius: 14px;
  -moz-border-radius:14px ;
  -webkit-border-radius: 14px;
  -khtml-border-radius: 14px;
  cursor:pointer;
  background-image:url(../images/buscarListado.png);
  background-repeat:no-repeat;
    box-shadow: 1px 0.5px 2px #000;
  -webkit-box-shadow: 1px 0.5px 2px #000;
  -moz-box-shadow: 1px 0.5px 2px #000;
  filter: shadow(color=#000, direction=135, strength=2);
  border:0px solid;
}


.listadoCombo1{
  position:absolute;
  left:100px;
  top:120px;		
}

.borde2Combo1{
  position:absolute;
  top:5.8px;
  left:5px;
  width:172px;
  height:23px;   
  color:#FFF;
  background-color:#000;
  z-index:311;
  border-radius: 10px;
  -moz-border-radius:10px ;
  -webkit-border-radius: 10px;
  -khtml-border-radius: 10px;
  border:0px;
  padding-left:6px;  
}

</style>


<script>
$(document).ready(function()
{
<?php	

echo "	
$('#fecha').datepicker({
showOn: 'button',
buttonImage: 'css/images/calendar.gif',
buttonImageOnly: true,
dateFormat: 'dd/mm/yy' });";

?>




});

	
	 
</script>
</head>

<body>

   <div class="contenedorSearch">
      <div class="borde1Usuario"> </div>
        <input type="button" class="iconSearch"/>
        <input type="text"  name="filtro" id="filtro" class="borde2Usuario"/>
      
   </div>  
   
   
   <div class="listadoCombo1">
          <div class="borde1Usuario"> </div>
            <select class="borde2Combo1">
              <option value="id">Nro</option>
              <option value="nombre">Nombre</option>
            </select>
   </div> 
   
   <input name="fecha" type="text" id="fecha" style="border:solid 1px #999;" size="12" class="date" value="<? echo date("d/m/Y");?>"  />
</body>
</html>