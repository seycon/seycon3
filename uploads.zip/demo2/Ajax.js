

var selec = '';
var nombre_tabla = '';

function ajaxx() {
	if (window.XMLHttpRequest) { // si es firefox
		return new XMLHttpRequest(); // objeto q se ocupa de la conexion
	} else if (window.ActiveXObject) { // si es internet explorer
		return new ActiveXObject("Microsoft.XMLHTTP");
	}
}


function cargarCampos(valor) {
  nombre_tabla = valor;	
  peticion = ajaxx();
  peticion.open('GET', 'campos.php?tabla='+valor, true); 
  peticion.onreadystatechange = function() { 	
     if (peticion.readyState == 4) { 
		 document.getElementById('campos').innerHTML =  peticion.responseText; 	
     } else {
		 document.getElementById('campos').innerHTML = 'CARGANDO...'
	 }
  } 
  peticion.send(null); 
}


    function $(id){
		return document.getElementById(id); 
	}

    function vera(){
		numFilas = $('tabla').rows.length;
		for (i = 0; i<numFilas; i++){
			//$('tabla').rows[i].cells[0].
		}
	}
	
	function edit(){
	miTabla = $('tabla');
    i = 0;
	do{
		if (miTabla.rows[i].getElementsByTagName('input')[0].checked == true)	{
           selec += miTabla.rows[i].getElementsByTagName('input')[0].value+',';
		}
			i ++;
	} while (miTabla.rows.length != i)
}



function con(){

	edit();
	 selec = selec.slice(0, -1);
	 indice = $('combo_campos').selectedIndex; 
     donde = $('combo_campos').options[indice].value; 
	 indice3 = $('combo_condicion').selectedIndex; 
     condicion = $('combo_condicion').options[indice3].value; 
	 v = $('r').value;
	 cadena = 'selec='+selec+'&donde='+donde+'&condicion='+condicion+'&valor='+v+'&tabla='+nombre_tabla;
	 window.open('consulta.php?'+cadena, '_blank', 'scrollbars=yes,resizable=yes,width=1024,height=768,status=yes,location=yes,toolbar=yes');
	 selec = '';
}

